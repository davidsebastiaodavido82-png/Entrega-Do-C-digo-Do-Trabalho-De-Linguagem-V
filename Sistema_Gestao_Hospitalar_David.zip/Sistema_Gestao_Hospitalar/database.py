import sqlite3
from pathlib import Path
from hashlib import pbkdf2_hmac
import os

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "base_dados" / "hospital.db"

def hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    digest = pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 180_000)
    return salt.hex() + "$" + digest.hex()

def verify_password(password, stored):
    try:
        salt_hex, digest_hex = stored.split("$", 1)
        candidate = pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 180_000)
        return candidate.hex() == digest_hex
    except Exception:
        return False

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS utilizadores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL,
            perfil TEXT NOT NULL DEFAULT 'Administrador'
        );
        CREATE TABLE IF NOT EXISTS utentes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero_registo TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            nascimento TEXT,
            sexo TEXT,
            telefone TEXT,
            nif TEXT,
            endereco TEXT,
            criado_em TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS consultas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            utente_id INTEGER NOT NULL,
            data_consulta TEXT NOT NULL,
            diagnostico TEXT NOT NULL,
            observacoes TEXT,
            profissional TEXT,
            FOREIGN KEY(utente_id) REFERENCES utentes(id) ON DELETE CASCADE
        );
        """)
        user = con.execute("SELECT id FROM utilizadores WHERE username='David'").fetchone()
        if not user:
            con.execute(
                "INSERT INTO utilizadores(nome,username,senha_hash,perfil) VALUES(?,?,?,?)",
                ("David", "David", hash_password("David1234"), "Administrador")
            )

def authenticate(username, password):
    with connect() as con:
        row = con.execute("SELECT * FROM utilizadores WHERE username=?", (username.strip(),)).fetchone()
    if row and verify_password(password, row["senha_hash"]):
        return dict(row)
    return None

def next_patient_number():
    with connect() as con:
        row = con.execute("SELECT COUNT(*) AS total FROM utentes").fetchone()
    return f"SGH-{row['total'] + 1:05d}"
