import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from database import init_db, connect, authenticate, next_patient_number

BG = "#F3F6FB"
NAV = "#142B4A"
NAV2 = "#1D3C63"
BLUE = "#2563EB"
INK = "#172B4D"
MUTED = "#6B7A90"
WHITE = "#FFFFFF"
GREEN = "#15966A"

class HospitalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Gestão Hospitalar")
        self.root.geometry("1180x740")
        self.root.minsize(980, 640)
        self.user = None
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("Treeview", rowheight=30, font=("Segoe UI", 10), background="white", fieldbackground="white")
        self.style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#E8EEF7", foreground=INK)
        self.style.map("Treeview", background=[("selected", "#DCEAFE")], foreground=[("selected", INK)])
        self.login_screen()

    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def login_screen(self):
        self.clear()
        self.root.configure(bg=BG)
        outer = tk.Frame(self.root, bg=BG)
        outer.pack(fill="both", expand=True)
        panel = tk.Frame(outer, bg=WHITE, highlightbackground="#DDE5F0", highlightthickness=1)
        panel.place(relx=.5, rely=.5, anchor="center", width=430, height=510)
        tk.Frame(panel, bg=BLUE, height=8).pack(fill="x")
        tk.Label(panel, text="✚", font=("Segoe UI", 35, "bold"), fg=BLUE, bg=WHITE).pack(pady=(28, 2))
        tk.Label(panel, text="GESTÃO HOSPITALAR", font=("Segoe UI", 20, "bold"), fg=NAV, bg=WHITE).pack()
        tk.Label(panel, text="Plataforma de registo e acompanhamento clínico", font=("Segoe UI", 9), fg=MUTED, bg=WHITE).pack(pady=(5, 28))
        form = tk.Frame(panel, bg=WHITE)
        form.pack(fill="x", padx=48)
        tk.Label(form, text="Nome de utilizador", bg=WHITE, fg=INK, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.username = tk.Entry(form, font=("Segoe UI", 12), relief="solid", bd=1)
        self.username.pack(fill="x", ipady=9, pady=(7, 18))
        self.username.insert(0, "David")
        tk.Label(form, text="Palavra-passe", bg=WHITE, fg=INK, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.password = tk.Entry(form, show="●", font=("Segoe UI", 12), relief="solid", bd=1)
        self.password.pack(fill="x", ipady=9, pady=(7, 22))
        self.password.bind("<Return>", lambda e: self.do_login())
        tk.Button(form, text="Entrar no sistema", command=self.do_login, bg=BLUE, fg=WHITE,
                  activebackground=NAV2, activeforeground=WHITE, relief="flat",
                  font=("Segoe UI", 11, "bold"), cursor="hand2").pack(fill="x", ipady=11)
        tk.Label(panel, text="Acesso de demonstração: David / David1234", bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="bottom", pady=22)
        self.username.focus_set()

    def do_login(self):
        user = authenticate(self.username.get(), self.password.get())
        if not user:
            messagebox.showerror("Acesso recusado", "Utilizador ou palavra-passe incorretos.")
            return
        self.user = user
        self.dashboard()

    def dashboard(self):
        self.clear()
        self.root.configure(bg=BG)
        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True)
        sidebar = tk.Frame(shell, bg=NAV, width=225)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="✚  SGH", bg=NAV, fg=WHITE, font=("Segoe UI", 23, "bold")).pack(anchor="w", padx=24, pady=(28, 2))
        tk.Label(sidebar, text="SISTEMA HOSPITALAR", bg=NAV, fg="#9FB4D0", font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=27, pady=(0, 35))
        self.nav_button(sidebar, "▦   Painel principal", self.home)
        self.nav_button(sidebar, "♙   Utentes", self.patients)
        self.nav_button(sidebar, "▤   Consultas", self.consultations)
        self.nav_button(sidebar, "◷   Histórico clínico", self.history)
        tk.Frame(sidebar, bg="#36516F", height=1).pack(fill="x", padx=18, pady=22)
        tk.Label(sidebar, text=f"Sessão: {self.user['nome']}", bg=NAV, fg="#D7E3F2", font=("Segoe UI", 10)).pack(anchor="w", padx=23)
        tk.Button(sidebar, text="Terminar sessão", command=self.login_screen, bg=NAV2, fg=WHITE, relief="flat",
                  font=("Segoe UI", 9), cursor="hand2").pack(side="bottom", fill="x", padx=18, pady=20, ipady=8)
        self.content = tk.Frame(shell, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)
        self.home()

    def nav_button(self, parent, text, command):
        tk.Button(parent, text=text, command=command, anchor="w", padx=22, bg=NAV, fg="#E7EEF8",
                  activebackground=NAV2, activeforeground=WHITE, relief="flat",
                  font=("Segoe UI", 10), cursor="hand2").pack(fill="x", ipady=13)

    def page(self, title, subtitle=""):
        for w in self.content.winfo_children():
            w.destroy()
        head = tk.Frame(self.content, bg=WHITE, height=88)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text=title, bg=WHITE, fg=INK, font=("Segoe UI", 19, "bold")).pack(anchor="w", padx=30, pady=(17, 0))
        tk.Label(head, text=subtitle, bg=WHITE, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=31, pady=(2, 0))
        body = tk.Frame(self.content, bg=BG)
        body.pack(fill="both", expand=True, padx=28, pady=24)
        return body

    def card(self, parent, title, value, color):
        box = tk.Frame(parent, bg=WHITE, highlightbackground="#E1E8F1", highlightthickness=1)
        box.pack(side="left", fill="both", expand=True, padx=(0, 14), ipady=15)
        tk.Label(box, text=title, bg=WHITE, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=18, pady=(14, 4))
        tk.Label(box, text=str(value), bg=WHITE, fg=color, font=("Segoe UI", 25, "bold")).pack(anchor="w", padx=18)
        return box

    def counts(self):
        with connect() as con:
            p = con.execute("SELECT COUNT(*) n FROM utentes").fetchone()["n"]
            c = con.execute("SELECT COUNT(*) n FROM consultas").fetchone()["n"]
            today = con.execute("SELECT COUNT(*) n FROM consultas WHERE data_consulta=?", (date.today().isoformat(),)).fetchone()["n"]
        return p, c, today

    def home(self):
        body = self.page("Painel principal", "Visão geral da atividade da unidade de saúde")
        p, c, today = self.counts()
        cards = tk.Frame(body, bg=BG)
        cards.pack(fill="x")
        self.card(cards, "Utentes registados", p, BLUE)
        self.card(cards, "Consultas registadas", c, GREEN)
        self.card(cards, "Atendimentos de hoje", today, "#C17A16")
        welcome = tk.Frame(body, bg=WHITE, highlightbackground="#E1E8F1", highlightthickness=1)
        welcome.pack(fill="x", pady=22)
        tk.Label(welcome, text=f"Bem-vindo(a), {self.user['nome']}!", bg=WHITE, fg=INK,
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=24, pady=(22, 5))
        tk.Label(welcome, text="Utilize o menu lateral para registar utentes, documentar consultas e consultar históricos clínicos.",
                 bg=WHITE, fg=MUTED, font=("Segoe UI", 10), wraplength=780).pack(anchor="w", padx=24, pady=(0, 22))
        tk.Label(body, text="Acesso rápido", bg=BG, fg=INK, font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(4, 10))
        quick = tk.Frame(body, bg=BG); quick.pack(anchor="w")
        tk.Button(quick, text="+ Novo utente", command=self.patient_form, bg=BLUE, fg=WHITE, relief="flat", padx=18, pady=10).pack(side="left", padx=(0, 10))
        tk.Button(quick, text="+ Registar consulta", command=self.consultation_form, bg=GREEN, fg=WHITE, relief="flat", padx=18, pady=10).pack(side="left")

    def patients(self):
        body = self.page("Gestão de utentes", "Registo, identificação e pesquisa dos utentes")
        bar = tk.Frame(body, bg=BG); bar.pack(fill="x", pady=(0, 12))
        search = tk.Entry(bar, font=("Segoe UI", 10), width=38, relief="solid", bd=1)
        search.pack(side="left", ipady=8)
        tk.Button(bar, text="Pesquisar", command=lambda: self.load_patients(tree, search.get()), bg=NAV2, fg=WHITE, relief="flat", padx=15, pady=8).pack(side="left", padx=8)
        tk.Button(bar, text="+ Novo utente", command=self.patient_form, bg=BLUE, fg=WHITE, relief="flat", padx=15, pady=8).pack(side="right")
        tree = ttk.Treeview(body, columns=("numero","nome","telefone","nif","sexo"), show="headings")
        for col, label, width in [("numero","N.º DE REGISTO",130),("nome","NOME COMPLETO",280),("telefone","TELEFONE",150),("nif","NIF",140),("sexo","SEXO",100)]:
            tree.heading(col, text=label); tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        self.load_patients(tree)
        tk.Button(body, text="Ver histórico do utente selecionado", command=lambda: self.open_selected_history(tree), bg="#E3ECFA", fg=NAV, relief="flat", padx=14, pady=9).pack(anchor="e", pady=10)

    def load_patients(self, tree, term=""):
        for i in tree.get_children(): tree.delete(i)
        like = f"%{term.strip()}%"
        with connect() as con:
            rows = con.execute("""SELECT * FROM utentes WHERE numero_registo LIKE ? OR nome LIKE ? OR telefone LIKE ? OR nif LIKE ? ORDER BY id DESC""",
                               (like, like, like, like)).fetchall()
        for r in rows:
            tree.insert("", "end", iid=str(r["id"]), values=(r["numero_registo"],r["nome"],r["telefone"] or "",r["nif"] or "",r["sexo"] or ""))

    def patient_form(self):
        win = tk.Toplevel(self.root); win.title("Registar utente"); win.configure(bg=WHITE); win.geometry("510x560"); win.transient(self.root); win.grab_set()
        tk.Label(win, text="Novo registo de utente", bg=WHITE, fg=INK, font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=25, pady=(22, 15))
        fields = {}
        specs = [("Nome completo","nome"),("Data de nascimento (AAAA-MM-DD)","nascimento"),("Telefone","telefone"),("NIF (opcional)","nif"),("Endereço","endereco")]
        form = tk.Frame(win, bg=WHITE); form.pack(fill="x", padx=25)
        for label, key in specs:
            tk.Label(form, text=label, bg=WHITE, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(7,2))
            ent = tk.Entry(form, font=("Segoe UI", 10), relief="solid", bd=1); ent.pack(fill="x", ipady=7); fields[key]=ent
        tk.Label(form, text="Sexo", bg=WHITE, fg=MUTED, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(8,2))
        sex = ttk.Combobox(form, values=["Feminino","Masculino","Outro","Não informado"], state="readonly"); sex.pack(fill="x", ipady=4); sex.set("Não informado")
        def save():
            name = fields["nome"].get().strip()
            if not name:
                messagebox.showwarning("Validação", "O nome completo é obrigatório.", parent=win); return
            with connect() as con:
                number = next_patient_number()
                con.execute("""INSERT INTO utentes(numero_registo,nome,nascimento,sexo,telefone,nif,endereco)
                               VALUES(?,?,?,?,?,?,?)""",
                            (number,name,fields["nascimento"].get().strip(),sex.get(),fields["telefone"].get().strip(),
                             fields["nif"].get().strip() or None,fields["endereco"].get().strip()))
            messagebox.showinfo("Sucesso", f"Utente registado com o número {number}.", parent=win)
            win.destroy()
            self.patients()
        tk.Button(win, text="Guardar registo", command=save, bg=BLUE, fg=WHITE, relief="flat", padx=20, pady=10).pack(anchor="e", padx=25, pady=20)

    def consultations(self):
        body = self.page("Consultas", "Registo de atendimentos e informação clínica")
        bar = tk.Frame(body, bg=BG); bar.pack(fill="x", pady=(0,12))
        tk.Button(bar, text="+ Nova consulta", command=self.consultation_form, bg=GREEN, fg=WHITE, relief="flat", padx=16, pady=9).pack(side="left")
        tree = ttk.Treeview(body, columns=("data","numero","utente","diagnostico","profissional"), show="headings")
        for col,label,width in [("data","DATA",115),("numero","N.º REGISTO",130),("utente","UTENTE",230),("diagnostico","DIAGNÓSTICO",300),("profissional","PROFISSIONAL",160)]:
            tree.heading(col,text=label); tree.column(col,width=width,anchor="w")
        tree.pack(fill="both",expand=True)
        with connect() as con:
            rows = con.execute("""SELECT c.*,u.numero_registo,u.nome FROM consultas c JOIN utentes u ON u.id=c.utente_id ORDER BY c.id DESC""").fetchall()
        for r in rows: tree.insert("","end",values=(r["data_consulta"],r["numero_registo"],r["nome"],r["diagnostico"],r["profissional"] or ""))

    def consultation_form(self):
        with connect() as con:
            patients = con.execute("SELECT id,numero_registo,nome FROM utentes ORDER BY nome").fetchall()
        if not patients:
            messagebox.showinfo("Sem utentes", "Registe primeiro pelo menos um utente."); return
        win=tk.Toplevel(self.root); win.title("Registar consulta"); win.configure(bg=WHITE); win.geometry("540x560"); win.transient(self.root); win.grab_set()
        tk.Label(win,text="Registo de consulta",bg=WHITE,fg=INK,font=("Segoe UI",17,"bold")).pack(anchor="w",padx=25,pady=(22,14))
        form=tk.Frame(win,bg=WHITE); form.pack(fill="x",padx=25)
        tk.Label(form,text="Utente",bg=WHITE,fg=MUTED).pack(anchor="w")
        choices=[f"{p['numero_registo']} — {p['nome']}" for p in patients]
        patient=ttk.Combobox(form,values=choices,state="readonly"); patient.pack(fill="x",ipady=5); patient.current(0)
        def field(label, height=1):
            tk.Label(form,text=label,bg=WHITE,fg=MUTED).pack(anchor="w",pady=(12,3))
            if height==1:
                e=tk.Entry(form,font=("Segoe UI",10),relief="solid",bd=1); e.pack(fill="x",ipady=7); return e
            t=tk.Text(form,height=height,font=("Segoe UI",10),relief="solid",bd=1); t.pack(fill="x"); return t
        dt=field("Data da consulta (AAAA-MM-DD)"); dt.insert(0,date.today().isoformat())
        diag=field("Diagnóstico")
        obs=field("Observações clínicas",5)
        prof=field("Profissional de saúde"); prof.insert(0,self.user["nome"])
        def save():
            if not diag.get().strip():
                messagebox.showwarning("Validação","O diagnóstico é obrigatório.",parent=win); return
            idx=patient.current(); p=patients[idx]
            with connect() as con:
                con.execute("INSERT INTO consultas(utente_id,data_consulta,diagnostico,observacoes,profissional) VALUES(?,?,?,?,?)",
                            (p["id"],dt.get().strip(),diag.get().strip(),obs.get("1.0","end").strip(),prof.get().strip()))
            messagebox.showinfo("Sucesso","Consulta registada.",parent=win); win.destroy(); self.consultations()
        tk.Button(win,text="Guardar consulta",command=save,bg=GREEN,fg=WHITE,relief="flat",padx=20,pady=10).pack(anchor="e",padx=25,pady=20)

    def history(self):
        body=self.page("Histórico clínico","Pesquise pelo número eletrónico ou pelo nome do utente")
        bar=tk.Frame(body,bg=BG); bar.pack(fill="x",pady=(0,12))
        ent=tk.Entry(bar,font=("Segoe UI",11),width=42,relief="solid",bd=1); ent.pack(side="left",ipady=8)
        tree=ttk.Treeview(body,columns=("data","diagnostico","observacoes","profissional"),show="headings")
        for col,label,width in [("data","DATA",120),("diagnostico","DIAGNÓSTICO",240),("observacoes","OBSERVAÇÕES",390),("profissional","PROFISSIONAL",150)]:
            tree.heading(col,text=label); tree.column(col,width=width,anchor="w")
        tree.pack(fill="both",expand=True)
        def search():
            for i in tree.get_children(): tree.delete(i)
            term=ent.get().strip()
            with connect() as con:
                u=con.execute("SELECT * FROM utentes WHERE numero_registo=? OR nome LIKE ?",(term,f"%{term}%")).fetchone()
                if not u:
                    messagebox.showinfo("Pesquisa","Nenhum utente encontrado."); return
                rows=con.execute("SELECT * FROM consultas WHERE utente_id=? ORDER BY data_consulta DESC",(u["id"],)).fetchall()
            title.config(text=f"{u['numero_registo']}  |  {u['nome']}")
            for r in rows: tree.insert("","end",values=(r["data_consulta"],r["diagnostico"],r["observacoes"] or "",r["profissional"] or ""))
        tk.Button(bar,text="Consultar histórico",command=search,bg=BLUE,fg=WHITE,relief="flat",padx=14,pady=8).pack(side="left",padx=8)
        title=tk.Label(body,text="Nenhum utente selecionado",bg=BG,fg=INK,font=("Segoe UI",11,"bold")); title.pack(anchor="w",pady=(4,10))

    def open_selected_history(self, tree):
        sel=tree.selection()
        if not sel:
            messagebox.showinfo("Seleção","Selecione um utente na lista."); return
        with connect() as con:
            u=con.execute("SELECT numero_registo FROM utentes WHERE id=?",(int(sel[0]),)).fetchone()
        self.history()
        # The user can search using the unique number shown in the patient list.

if __name__ == "__main__":
    init_db()
    root=tk.Tk()
    app=HospitalApp(root)
    root.mainloop()
